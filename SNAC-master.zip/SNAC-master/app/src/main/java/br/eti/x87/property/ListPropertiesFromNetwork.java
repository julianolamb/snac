package br.eti.x87.property;

import java.util.ArrayList;

public class ListPropertiesFromNetwork implements ListProperties {
    @Override
    public CharSequence[] getPropertiesList() {
        //TODO
        return null;
    }

    @Override
    public ArrayList<String> getPropertiesListArray() {
        return null;
    }
}
