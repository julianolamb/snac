package br.eti.x87.property;

import java.util.ArrayList;

public interface ListProperties {
    public CharSequence[] getPropertiesList();
    public ArrayList<String> getPropertiesListArray();
}

